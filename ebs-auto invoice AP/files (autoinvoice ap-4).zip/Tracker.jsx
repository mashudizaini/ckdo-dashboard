// src/pages/Tracker.jsx
import { useState, useEffect, useCallback } from "react";
import { listInvoices, getRequestStatus } from "../services/api.js";
import StatusBadge from "../components/StatusBadge.jsx";

const fmt = (n) =>
  n != null ? Number(n).toLocaleString("id-ID", { minimumFractionDigits: 0 }) : "-";

export default function Tracker({ onReview }) {
  const [invoices,  setInvoices]  = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [checking,  setChecking]  = useState(null);
  const [reqStatus, setReqStatus] = useState({});

  const load = useCallback(async () => {
    try {
      const data = await listInvoices();
      setInvoices(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000); // auto-refresh 15 detik
    return () => clearInterval(interval);
  }, [load]);

  const checkStatus = async (stgId) => {
    setChecking(stgId);
    try {
      const res = await getRequestStatus(stgId);
      setReqStatus((prev) => ({ ...prev, [stgId]: res }));
      await load(); // refresh list
    } catch (e) {
      console.error(e);
    } finally {
      setChecking(null);
    }
  };

  const STATUS_ORDER = ["NEW","VALIDATED","PROCESSING","INTERFACED","IMPORTED","ERROR"];
  const summary = STATUS_ORDER.reduce((acc, s) => {
    acc[s] = invoices.filter((i) => i.status === s).length;
    return acc;
  }, {});

  return (
    <div style={{ maxWidth: 1100, margin: "24px auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ color: "#1e3a5f", margin: 0 }}>📊 Status Tracker</h2>
        <button onClick={load} style={{ ...btnStyle("#475569"), padding: "6px 16px", fontSize: 13 }}>
          ↻ Refresh
        </button>
      </div>

      {/* Summary cards */}
      <div style={{ display: "flex", gap: 12, marginBottom: 24, flexWrap: "wrap" }}>
        {[
          { key: "IMPORTED",   label: "Selesai",     color: "#15803d", bg: "#dcfce7" },
          { key: "INTERFACED", label: "Dikirim",     color: "#7c3aed", bg: "#ede9fe" },
          { key: "VALIDATED",  label: "Tervalidasi", color: "#1d4ed8", bg: "#dbeafe" },
          { key: "NEW",        label: "Baru",         color: "#6b7280", bg: "#f3f4f6" },
          { key: "ERROR",      label: "Error",        color: "#b91c1c", bg: "#fee2e2" },
        ].map(({ key, label, color, bg }) => (
          <div key={key} style={{
            background: bg, borderRadius: 10, padding: "12px 20px",
            minWidth: 110, textAlign: "center",
          }}>
            <div style={{ fontSize: 24, fontWeight: 700, color }}>{summary[key] || 0}</div>
            <div style={{ fontSize: 12, color, fontWeight: 500 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Table */}
      {loading ? (
        <p style={{ color: "#94a3b8", textAlign: "center" }}>Memuat data...</p>
      ) : invoices.length === 0 ? (
        <p style={{ color: "#94a3b8", textAlign: "center" }}>Belum ada invoice yang diupload.</p>
      ) : (
        <div style={{ background: "#fff", borderRadius: 12, boxShadow: "0 1px 4px #0001", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ background: "#f8fafc", color: "#64748b" }}>
                {["STG ID","Invoice No","Vendor","Tgl Invoice","Amount (IDR)","Status","Upload","Aksi"].map(h => (
                  <th key={h} style={{ padding: "10px 14px", textAlign: "left", fontWeight: 600, whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => (
                <>
                  <tr key={inv.stg_id} style={{ borderBottom: "1px solid #f1f5f9" }}
                    onMouseEnter={e => e.currentTarget.style.background = "#f8fafc"}
                    onMouseLeave={e => e.currentTarget.style.background = "transparent"}
                  >
                    <td style={{ padding: "10px 14px", color: "#94a3b8" }}>{inv.stg_id}</td>
                    <td style={{ padding: "10px 14px", fontWeight: 600, color: "#1e293b" }}>{inv.invoice_num}</td>
                    <td style={{ padding: "10px 14px" }}>{inv.vendor_name}</td>
                    <td style={{ padding: "10px 14px" }}>{inv.invoice_date || "-"}</td>
                    <td style={{ padding: "10px 14px", textAlign: "right", fontWeight: 600 }}>{fmt(inv.invoice_amount)}</td>
                    <td style={{ padding: "10px 14px" }}><StatusBadge status={inv.status} /></td>
                    <td style={{ padding: "10px 14px", color: "#94a3b8", fontSize: 12 }}>{inv.created_date}</td>
                    <td style={{ padding: "10px 14px" }}>
                      <div style={{ display: "flex", gap: 6 }}>
                        {inv.status in { NEW:1, VALIDATED:1, ERROR:1 } && (
                          <button onClick={() => onReview(inv.stg_id)} style={actBtn("#1d4ed8")}>
                            Review
                          </button>
                        )}
                        {inv.status in { INTERFACED:1, IMPORTED:1 } && (
                          <button
                            onClick={() => checkStatus(inv.stg_id)}
                            disabled={checking === inv.stg_id}
                            style={actBtn("#7c3aed")}
                          >
                            {checking === inv.stg_id ? "..." : "Cek"}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>

                  {/* Request status row */}
                  {reqStatus[inv.stg_id] && (
                    <tr key={`rs-${inv.stg_id}`}>
                      <td colSpan={8} style={{ padding: "0 14px 10px 14px" }}>
                        <div style={{
                          background: "#f8fafc", borderRadius: 8,
                          padding: "8px 14px", fontSize: 12, color: "#475569",
                        }}>
                          {(() => {
                            const rs = reqStatus[inv.stg_id];
                            const parts = [];
                            if (rs.concurrent) {
                              parts.push(`Concurrent: ${rs.concurrent.phase} / ${rs.concurrent.status}`);
                              if (rs.concurrent.completion_text) parts.push(rs.concurrent.completion_text);
                            }
                            if (rs.import) {
                              parts.push(`EBS Import: ${rs.import.status}`);
                              if (rs.import.invoice_id) parts.push(`Invoice ID: ${rs.import.invoice_id}`);
                              if (rs.import.error_msg) parts.push(`⚠️ ${rs.import.error_msg}`);
                            }
                            return parts.join(" | ");
                          })()}
                        </div>
                      </td>
                    </tr>
                  )}

                  {/* Error message row */}
                  {inv.status === "ERROR" && inv.error_msg && (
                    <tr key={`err-${inv.stg_id}`}>
                      <td colSpan={8} style={{ padding: "0 14px 10px 14px" }}>
                        <div style={{
                          background: "#fef2f2", borderRadius: 8,
                          padding: "6px 14px", fontSize: 12, color: "#b91c1c",
                        }}>
                          ⚠️ {inv.error_msg}
                        </div>
                      </td>
                    </tr>
                  )}
                </>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

const btnStyle = (bg) => ({
  padding: "7px 16px", background: bg, color: "#fff",
  border: "none", borderRadius: 6, fontWeight: 600, cursor: "pointer",
});

const actBtn = (bg) => ({
  padding: "4px 10px", background: bg, color: "#fff",
  border: "none", borderRadius: 5, fontSize: 12, cursor: "pointer", fontWeight: 600,
});
