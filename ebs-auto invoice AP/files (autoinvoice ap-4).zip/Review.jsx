// src/pages/Review.jsx
import { useState } from "react";
import { validateInvoice, submitInvoice, updateInvoice } from "../services/api.js";
import StatusBadge from "../components/StatusBadge.jsx";

const fmt = (n) =>
  n != null ? Number(n).toLocaleString("id-ID", { minimumFractionDigits: 2 }) : "-";

export default function Review({ invoice, onDone }) {
  const [data,    setData]    = useState(invoice.preview || invoice);
  const [stgId]              = useState(invoice.stg_id);
  const [status,  setStatus]  = useState("NEW");
  const [loading, setLoading] = useState(false);
  const [msg,     setMsg]     = useState(invoice.message || "");
  const [error,   setError]   = useState(null);

  const field = (label, key, editable = false) => (
    <div style={{ display: "flex", gap: 8, padding: "6px 0", borderBottom: "1px solid #f1f5f9" }}>
      <span style={{ width: 160, color: "#64748b", fontSize: 13, flexShrink: 0 }}>{label}</span>
      {editable ? (
        <input
          value={data[key] || ""}
          onChange={(e) => setData({ ...data, [key]: e.target.value })}
          style={{
            flex: 1, border: "1px solid #cbd5e1", borderRadius: 6,
            padding: "2px 8px", fontSize: 13,
          }}
        />
      ) : (
        <span style={{ fontWeight: 500, fontSize: 13, color: "#1e293b" }}>
          {data[key] || "-"}
        </span>
      )}
    </div>
  );

  const handleValidate = async () => {
    setLoading(true); setError(null);
    try {
      // Save edits first
      await updateInvoice(stgId, {
        invoice_num:  data.invoice_num,
        invoice_date: data.invoice_date,
        vendor_name:  data.vendor_name,
        po_number:    data.po_number,
        terms_date:   data.terms_date,
      });
      const res = await validateInvoice(stgId);
      setStatus("VALIDATED");
      setMsg(res.message);
    } catch (e) {
      setError(e.message);
      setStatus("ERROR");
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async () => {
    setLoading(true); setError(null);
    try {
      const res = await submitInvoice(stgId);
      setStatus("INTERFACED");
      setMsg(res.message);
      setTimeout(() => onDone(), 1500);
    } catch (e) {
      setError(e.message);
      setStatus("ERROR");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: 800, margin: "24px auto" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
        <h2 style={{ color: "#1e3a5f", margin: 0 }}>Review Invoice</h2>
        <StatusBadge status={status} />
      </div>

      {/* Header */}
      <div style={{ background: "#fff", borderRadius: 12, padding: 20, marginBottom: 16, boxShadow: "0 1px 4px #0001" }}>
        <h4 style={{ color: "#475569", marginBottom: 12, marginTop: 0 }}>📋 Header</h4>
        {field("Invoice No.",    "invoice_num",  true)}
        {field("Invoice Date",   "invoice_date", true)}
        {field("Vendor Name",    "vendor_name",  true)}
        {field("PO Number",      "po_number",    true)}
        {field("SO Number",      "so_number")}
        {field("Jatuh Tempo",    "terms_date")}
        {field("Currency",       "currency_code")}
      </div>

      {/* Totals */}
      <div style={{ background: "#fff", borderRadius: 12, padding: 20, marginBottom: 16, boxShadow: "0 1px 4px #0001" }}>
        <h4 style={{ color: "#475569", marginBottom: 12, marginTop: 0 }}>💰 Nilai</h4>
        {field("Subtotal",    "subtotal"   )}
        {field("PPN (Tax)",   "tax_amount" )}
        {field("Total (IDR)", "invoice_amount")}
      </div>

      {/* Lines */}
      <div style={{ background: "#fff", borderRadius: 12, padding: 20, marginBottom: 16, boxShadow: "0 1px 4px #0001" }}>
        <h4 style={{ color: "#475569", marginBottom: 12, marginTop: 0 }}>📦 Line Items</h4>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr style={{ background: "#f8fafc", color: "#64748b" }}>
              {["#","Kode","Deskripsi","Batch","Qty","Harga","Amount"].map(h => (
                <th key={h} style={{ padding: "8px 10px", textAlign: h === "#" || h === "Qty" ? "center" : "left", fontWeight: 600 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(data.lines || []).map((ln) => (
              <tr key={ln.line_num} style={{ borderBottom: "1px solid #f1f5f9" }}>
                <td style={{ padding: "8px 10px", textAlign: "center", color: "#94a3b8" }}>{ln.line_num}</td>
                <td style={{ padding: "8px 10px" }}>{ln.item_code || "-"}</td>
                <td style={{ padding: "8px 10px" }}>{ln.description}</td>
                <td style={{ padding: "8px 10px" }}>{ln.batch_no || "-"}</td>
                <td style={{ padding: "8px 10px", textAlign: "center" }}>{ln.qty}</td>
                <td style={{ padding: "8px 10px", textAlign: "right" }}>{fmt(ln.unit_price)}</td>
                <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 600 }}>{fmt(ln.line_amount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Messages */}
      {msg && (
        <div style={{ padding: "10px 16px", background: "#f0fdf4", borderRadius: 8, color: "#15803d", fontSize: 13, marginBottom: 12 }}>
          ✅ {msg}
        </div>
      )}
      {error && (
        <div style={{ padding: "10px 16px", background: "#fee2e2", borderRadius: 8, color: "#b91c1c", fontSize: 13, marginBottom: 12 }}>
          ⚠️ {error}
        </div>
      )}

      {/* Actions */}
      <div style={{ display: "flex", gap: 12, justifyContent: "flex-end" }}>
        {status !== "INTERFACED" && status !== "IMPORTED" && (
          <button onClick={handleValidate} disabled={loading} style={btnStyle("#1d4ed8")}>
            {loading && status === "NEW" ? "Validating..." : "🔍 Validate"}
          </button>
        )}
        {status === "VALIDATED" && (
          <button onClick={handleSubmit} disabled={loading} style={btnStyle("#15803d")}>
            {loading ? "Submitting..." : "🚀 Submit ke EBS"}
          </button>
        )}
      </div>
    </div>
  );
}

const btnStyle = (bg) => ({
  padding:      "10px 24px",
  background:   bg,
  color:        "#fff",
  border:       "none",
  borderRadius: 8,
  fontWeight:   600,
  cursor:       "pointer",
  fontSize:     14,
});
