import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      // Dev mode: proxy API ke backend
      "/api": {
        target:      "http://localhost:8000",
        rewrite:     (path) => path.replace(/^\/api/, ""),
        changeOrigin: true,
      },
    },
  },
});
